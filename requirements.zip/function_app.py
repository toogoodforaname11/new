import azure.functions as func
import requests
import os
import logging
from notedx_sdk import NoteDxClient

# Initialize the Function App (V2 Model)
app = func.FunctionApp(http_auth_level=func.AuthLevel.FUNCTION)

@app.route(route="ProcessNote")
def ProcessNote(req: func.HttpRequest) -> func.HttpResponse:
    logging.info('Python HTTP trigger function processing a NoteDx request.')
    
    try:
        # 1. Get the patient text from the incoming request
        req_body = req.get_json()
        raw_text = req_body.get('text')

        if not raw_text:
            return func.HttpResponse("Please pass 'text' in the request body", status_code=400)

        # 2. Initialize NoteDx SDK (using your Environment Variables)
        client = NoteDxClient(api_key=os.environ["NOTEDX_API_KEY"])
        
        # 3. Process the medical note via NoteDx
        notedx_resp = client.notes.process_text(text=raw_text, template="primaryCare")

        # 4. Push the result to your n8n Webhook with your secret header
        n8n_headers = {"X-CLINIC-AUTH": os.environ["N8N_SECRET"]}
        payload = {
            "note": notedx_resp['note'],
            "transcript": notedx_resp['transcript'],
            "status": "success"
        }
        
        requests.post(os.environ["N8N_WEBHOOK_URL"], json=payload, headers=n8n_headers)

        return func.HttpResponse("Success: Medical note sent to n8n", status_code=200)

    except Exception as e:
        logging.error(f"Error: {str(e)}")
        return func.HttpResponse(f"Error: {str(e)}", status_code=500)